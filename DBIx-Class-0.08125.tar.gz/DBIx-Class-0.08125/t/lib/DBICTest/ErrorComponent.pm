#   belongs to t/run/90ensure_class_loaded.tl
package # hide from PAUSE 
    DBICTest::ErrorComponent;
use warnings;
use strict;

# this is missing on purpose
# 1;
